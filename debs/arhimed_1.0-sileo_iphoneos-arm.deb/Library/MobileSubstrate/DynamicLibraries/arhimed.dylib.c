#include <stdio.h>
#include <unistd.h>
#include <UIKit/UIKit.h>

__attribute__((constructor)) static void init() {
    printf("[arhimed] Твик загружен!\n");
    
    // Через 1 секунду покажем уведомление
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 1 * NSEC_PER_SEC), 
                   dispatch_get_main_queue(), ^{
        // Показываем алерт
        UIAlertView *alert = [[UIAlertView alloc] 
            initWithTitle:@"arhimed"
            message:@"Твик успешно установлен! Зайдите в Настройки -> arhimed"
            delegate:nil
            cancelButtonTitle:@"OK"
            otherButtonTitles:nil];
        [alert show];
        [alert release];
    });
}
